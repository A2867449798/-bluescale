package com.bluescale;

import android.Manifest;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private static final UUID SVC = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb");
    private static final UUID CHR = UUID.fromString("0000fff1-0000-1000-8000-00805f9b34fb");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final Pattern FRAME = Pattern.compile("(\\d{1,6}\\.\\d{1,4})");
    private static final int REQ_CODE = 1001;
    private static final String PREF = "bluescale";

    private TextView tvState, tvWeight, tvRaw, tvAmount, tvList;
    private EditText etPrice, etFactor;
    private CheckBox cbReverse;

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private final StringBuilder sb = new StringBuilder();
    private final Map<String, BluetoothDevice> found = new LinkedHashMap<>();
    private final Handler ui = new Handler(Looper.getMainLooper());

    private String origStr = null;
    private double tareGram = 0;
    private double price = 0;
    private double factor = 1;
    private boolean reverse = true;
    private final List<String> rows = new ArrayList<>();
    private double total = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        tvState = findViewById(R.id.tvState);
        tvWeight = findViewById(R.id.tvWeight);
        tvRaw = findViewById(R.id.tvRaw);
        tvAmount = findViewById(R.id.tvAmount);
        tvList = findViewById(R.id.tvList);
        etPrice = findViewById(R.id.etPrice);
        etFactor = findViewById(R.id.etFactor);
        cbReverse = findViewById(R.id.cbReverse);

        SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
        price = Double.longBitsToDouble(sp.getLong("price", Double.doubleToLongBits(0)));
        factor = Double.longBitsToDouble(sp.getLong("factor", Double.doubleToLongBits(1)));
        reverse = sp.getBoolean("reverse", true);
        if (price > 0) etPrice.setText(fmt(price, 2));
        etFactor.setText(fmt(factor, 3));
        cbReverse.setChecked(reverse);

        findViewById(R.id.btnConnect).setOnClickListener(v -> onConnectClick());
        findViewById(R.id.btnTare).setOnClickListener(v -> {
            tareGram = origStr == null ? 0 : toGrams(origStr) * factor;
            render();
        });
        findViewById(R.id.btnAdd).setOnClickListener(v -> addRow());

        etPrice.addTextChangedListener(new SimpleWatcher() {
            public void afterTextChanged(android.text.Editable e) {
                price = parse(etPrice.getText().toString(), 0);
                save();
                render();
            }
        });
        etFactor.addTextChangedListener(new SimpleWatcher() {
            public void afterTextChanged(android.text.Editable e) {
                factor = parse(etFactor.getText().toString(), 1);
                save();
                render();
            }
        });
        cbReverse.setOnCheckedChangeListener((v, on) -> {
            reverse = on;
            save();
            render();
        });

        render();
    }

    private void save() {
        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                .putLong("price", Double.doubleToLongBits(price))
                .putLong("factor", Double.doubleToLongBits(factor))
                .putBoolean("reverse", reverse)
                .apply();
    }

    private static double parse(String s, double def) {
        if (s == null || s.trim().isEmpty()) return def;
        try {
            return Double.parseDouble(s.trim());
        } catch (Exception e) {
            return def;
        }
    }

    private static String fmt(double v, int n) {
        return String.format(Locale.US, "%." + n + "f", v);
    }

    private double toGrams(String s) {
        if (s == null) return 0;
        if (!reverse) return parse(s, 0);
        String d = s.replaceAll("[^0-9]", "");
        if (d.isEmpty()) return 0;
        String r = new StringBuilder(d).reverse().toString();
        try {
            return Long.parseLong(r) * 10.0;
        } catch (Exception e) {
            return 0;
        }
    }

    private double currentGrams() {
        if (origStr == null) return 0;
        double g = toGrams(origStr) * factor - tareGram;
        return Math.max(0, g);
    }

    private void render() {
        double g = currentGrams();
        double kg = g / 1000.0;
        tvWeight.setText(fmt(kg, 3));
        tvAmount.setText("¥" + fmt(kg * price, 2));
        if (origStr == null) {
            tvRaw.setText("原始值 —");
        } else {
            tvRaw.setText("秤报 " + origStr + "　→ " + fmt(toGrams(origStr), 0)
                    + " g（" + fmt(kg, 3) + " kg）");
        }
    }

    private void addRow() {
        double g = currentGrams();
        if (g <= 0 || price <= 0) {
            Toast.makeText(this, "需要有效的重量和单价", Toast.LENGTH_SHORT).show();
            return;
        }
        double amt = g / 1000.0 * price;
        total += amt;
        rows.add(fmt(g / 1000.0, 3) + " kg × ¥" + fmt(price, 2) + " = ¥" + fmt(amt, 2));
        StringBuilder t = new StringBuilder();
        for (String r : rows) t.append(r).append("\n");
        t.append("—— 合计 ").append(rows.size()).append(" 笔：¥").append(fmt(total, 2));
        tvList.setText(t.toString());
    }

    private boolean hasPerm() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                    == PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void onConnectClick() {
        if (!hasPerm()) {
            String[] ps;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ps = new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT};
            } else {
                ps = new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
            }
            ActivityCompat.requestPermissions(this, ps, REQ_CODE);
            return;
        }
        startScan();
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] p, @NonNull int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == REQ_CODE) {
            if (hasPerm()) {
                startScan();
            } else {
                tvState.setText("未授予蓝牙权限，无法扫描");
            }
        }
    }

    private void startScan() {
        BluetoothManager bm = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm == null ? null : bm.getAdapter();
        if (adapter == null) {
            tvState.setText("此机不支持蓝牙");
            return;
        }
        if (!adapter.isEnabled()) {
            tvState.setText("请先在系统里打开蓝牙");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        found.clear();
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            tvState.setText("此机不支持蓝牙扫描");
            return;
        }
        tvState.setText("搜索中…请确保秤已开机");
        try {
            scanner.startScan(scanCb);
        } catch (Exception e) {
            tvState.setText("扫描失败：" + e.getMessage());
            return;
        }
        ui.postDelayed(this::stopScanAndPick, 8000);
    }

    private void stopScanAndPick() {
        try {
            if (scanner != null) scanner.stopScan(scanCb);
        } catch (Exception ignored) {
        }
        if (found.isEmpty()) {
            tvState.setText("未搜到设备，请确认秤已开机并在附近");
            return;
        }
        final String[] names = found.keySet().toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("选择你的秤")
                .setItems(names, (d, i) -> connectDevice(found.get(names[i])))
                .setNegativeButton("取消", null)
                .show();
        tvState.setText("已发现 " + found.size() + " 台设备，请选择");
    }

    private final ScanCallback scanCb = new ScanCallback() {
        @Override
        public void onScanResult(int type, ScanResult res) {
            BluetoothDevice d = res.getDevice();
            if (d == null) return;
            String n;
            try {
                n = d.getName();
            } catch (SecurityException e) {
                n = null;
            }
            if (n == null || n.isEmpty()) n = "未命名设备";
            String key = n + "   [" + d.getAddress() + "]";
            if (!found.containsKey(key)) {
                found.put(key, d);
                tvState.setText("已发现 " + found.size() + " 台，等待选择…");
            }
        }
    };

    private void connectDevice(BluetoothDevice d) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            tvState.setText("缺少蓝牙连接权限");
            return;
        }
        if (gatt != null) {
            gatt.close();
            gatt = null;
        }
        sb.setLength(0);
        tvState.setText("连接中…");
        gatt = d.connectGatt(this, false, gattCb, BluetoothDevice.TRANSPORT_LE);
    }

    private final BluetoothGattCallback gattCb = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread(() -> tvState.setText("已连接，正在发现服务…"));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                        && ActivityCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                g.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                runOnUiThread(() -> tvState.setText("已断开"));
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            BluetoothGattCharacteristic target = null;
            BluetoothGattService s = g.getService(SVC);
            if (s != null) target = s.getCharacteristic(CHR);
            if (target == null) {
                outer:
                for (BluetoothGattService sv : g.getServices()) {
                    for (BluetoothGattCharacteristic c : sv.getCharacteristics()) {
                        int p = c.getProperties();
                        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0
                                || (p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                            target = c;
                            break outer;
                        }
                    }
                }
            }
            if (target == null) {
                runOnUiThread(() -> tvState.setText("未找到可读的数据特征"));
                return;
            }
            final BluetoothGattCharacteristic ch = target;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    && ActivityCompat.checkSelfPermission(MainActivity.this,
                    Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            g.setCharacteristicNotification(ch, true);
            BluetoothGattDescriptor desc = ch.getDescriptor(CCCD);
            if (desc != null) {
                desc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                g.writeDescriptor(desc);
            }
            runOnUiThread(() -> tvState.setText("已连接　" + ch.getUuid().toString().substring(4, 8)));
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            handleData(c.getValue());
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            handleData(value);
        }
    };

    private void handleData(byte[] v) {
        if (v == null || v.length == 0) return;
        String s = new String(v, StandardCharsets.US_ASCII);
        sb.append(s);
        if (sb.length() > 4000) sb.delete(0, sb.length() - 2000);
        Matcher m = FRAME.matcher(sb.toString());
        String last = null;
        while (m.find()) last = m.group(1);
        if (last == null) return;
        final String val = last;
        runOnUiThread(() -> {
            origStr = val;
            render();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        try {
            if (scanner != null) scanner.stopScan(scanCb);
        } catch (Exception ignored) {
        }
        if (gatt != null) {
            try {
                gatt.disconnect();
                gatt.close();
            } catch (Exception ignored) {
            }
            gatt = null;
        }
    }

    private abstract static class SimpleWatcher implements android.text.TextWatcher {
        public void beforeTextChanged(CharSequence s, int a, int b, int c) {
        }

        public void onTextChanged(CharSequence s, int a, int b, int c) {
        }
    }
}
